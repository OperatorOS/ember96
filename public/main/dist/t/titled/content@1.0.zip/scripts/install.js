w96.WRT.runFile("c:/system/boot/apps/titled.js");
