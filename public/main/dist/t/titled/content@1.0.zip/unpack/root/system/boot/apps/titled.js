// Titlebar editor

const icons = {
    "16": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TpaIVBTuIOGSonSyIiuimVShChVArtOpgcukXNGlIUlwcBdeCgx+LVQcXZ10dXAVB8APEzc1J0UVK/F9aaBHjwXE/3t173L0DhFqJaVbHGKDptpmMx8R0ZlUMvKIHAvoxg4jMLGNOkhLwHF/38PH1LsqzvM/9OXrVrMUAn0g8ywzTJt4gntq0Dc77xCFWkFXic+JRky5I/Mh1pcFvnPMuCzwzZKaS88QhYjHfxkobs4KpEU8Sh1VNp3wh3WCV8xZnrVRhzXvyFwaz+soy12kOI45FLEGCCAUVFFGCjSitOikWkrQf8/APuX6JXAq5imDkWEAZGmTXD/4Hv7u1chPjjaRgDOh8cZyPESCwC9SrjvN97Dj1E8D/DFzpLX+5Bkx/kl5taeEjoG8buLhuacoecLkDDD4Zsim7kp+mkMsB72f0TRlg4BboXmv01tzH6QOQoq4SN8DBIRDJU/a6x7u72nv790yzvx+iSHK6lLoO8wAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+ULAhEMFhIB6hEAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAaklEQVQ4y8WTMQ6AMAwDL6jP6uCZB3f20H+ViYGBgloqvPsUJZcAGhNJAFHLULnlnfhkAttDZUlsTGYtQBKSxgCSiFqIWrqQrVc+04Os2YFtWt4vwtydOt2RbaMsnjxJvfHeCPa/SNPPdAAlNyKVrqSFUAAAAABJRU5ErkJggg==",
    "32": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TpaIVBTuIOGSonSyIiuimVShChVArtOpgcukXNGlIUlwcBdeCgx+LVQcXZ10dXAVB8APEzc1J0UVK/F9aaBHjwXE/3t173L0DhFqJaVbHGKDptpmMx8R0ZlUMvKIHAvoxg4jMLGNOkhLwHF/38PH1LsqzvM/9OXrVrMUAn0g8ywzTJt4gntq0Dc77xCFWkFXic+JRky5I/Mh1pcFvnPMuCzwzZKaS88QhYjHfxkobs4KpEU8Sh1VNp3wh3WCV8xZnrVRhzXvyFwaz+soy12kOI45FLEGCCAUVFFGCjSitOikWkrQf8/APuX6JXAq5imDkWEAZGmTXD/4Hv7u1chPjjaRgDOh8cZyPESCwC9SrjvN97Dj1E8D/DFzpLX+5Bkx/kl5taeEjoG8buLhuacoecLkDDD4Zsim7kp+mkMsB72f0TRlg4BboXmv01tzH6QOQoq4SN8DBIRDJU/a6x7u72nv790yzvx+iSHK6lLoO8wAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+ULAhEJIdfLu1sAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAy0lEQVRYw+2WMQ7DIAxFTeRbheGvyYHb1UN7rZCJChBqhAkwBE+JIuW/bxtjoqeHCZ7dCN0IwHxezZWd3QkAiYghIlpGl4BTuqEAItJcEED0PrwEE4DvqGNN/7BGODcvYKEC4RLxf4PKf4NFEcQtPXCsGx3r1q4Jr9ynmcj1SLMMeOfL9/2QORDWu9a9CsCLaZtOBSAi0U0ZOk7dO7sXHUNWk1ekXQUgIr9plzuSPkPNJmH4cw/S/S5osbjMfWAC8NWm0xPAAHA0o3OcoZ9Ndc6YgyAAAAAASUVORK5CYII="
}

class Titled extends w96.WApplication {
	constructor() {
		super();
	}
	async main(argv) {
		super.main(argv);
		const wnd = this.createWindow({
			title: "Titled",
			body: `
                <style>
                    #titled-main {
                        display: flex;
                        flex-direction: column;
                        padding: 0 5px;
                        box-sizing: border-box;
                        width: 100%;
                    }
                    #titled-app-title {
                        font-size: 16px;
                        padding-bottom: 5px;
                    }
                    #titled-options {
                        display: flex;
                    }
                    .titled-column {
                        display: flex;
                        flex-direction: column;
                        flex: 1;
                    }
                    .titled-option {
                        display: flex;
                        align-items: center;
                        box-sizing: border-box;
                        width: 100%;
                        padding-bottom: 5px;
                    }
                    .titled-option-title {
                        padding-right: 5px;
                        box-sizing: border-box;
                    }

                    .titled-color-select {
                        display: flex;
                        align-items: center;
                    }
                    .titled-color-select-preview {
                        width: 15px;
                        height: 15px;
                        box-sizing: border-box;
                        border: 1px solid black;
                        margin-right: 5px;
                    }
                    .titled-color-select-input {
                        box-sizing: border-box;
                        padding-left: 3px;
                        padding-right: 3px;
                        background: white;
                        width: 50px;
                    }

                    .titled-rotation-input {
                        width: 30px;
                    }
                </style>
                <div id="titled-main">
                    <div id="titled-app-title">Titled</div>
                    <div id="titled-options">
                        <div class="titled-column">
                            <b>Active windows</b>
                            <div class="titled-option">
                                <span class="titled-option-title">Color 1</span>
                                <div class="titled-color-select w96-button">
                                    <div class="titled-color-select-preview"></div>
                                    <span>#</span>
                                    <input type="text" class="titled-color-select-input w96-textbox" tcolor="1" tstate="1">
                                </div>
                            </div>
                            <div class="titled-option">
                                <span class="titled-option-title">Color 2</span>
                                <div class="titled-color-select w96-button">
                                    <div class="titled-color-select-preview"></div>
                                    <span>#</span>
                                    <input type="text" class="titled-color-select-input w96-textbox" tcolor="2" tstate="1">
                                </div>
                            </div>
                            <div class="titled-option">
                                <span class="titled-option-title">Rotation</span>
                                <input type="text" class="w96-textbox titled-rotation-input" value="90" tstate="1">
                                <span>°</span>
                            </div>
                        </div>
                        <div class="titled-column">
                            <b>Inactive windows</b>
                            <div class="titled-option">
                                <span class="titled-option-title">Color 1</span>
                                <div class="titled-color-select w96-button">
                                    <div class="titled-color-select-preview"></div>
                                    <span>#</span>
                                    <input type="text" class="titled-color-select-input w96-textbox" tcolor="1" tstate="2">
                                </div>
                            </div>
                            <div class="titled-option">
                                <span class="titled-option-title">Color 2</span>
                                <div class="titled-color-select w96-button">
                                    <div class="titled-color-select-preview"></div>
                                    <span>#</span>
                                    <input type="text" class="titled-color-select-input w96-textbox" tcolor="2" tstate="2">
                                </div>
                            </div>
                            <div class="titled-option">
                                <span class="titled-option-title">Rotation</span>
                                <input type="text" class="w96-textbox titled-rotation-input" value="90" tstate="2">
                                <span>°</span>
                            </div>
                        </div>
                    </div>
                    <label class="w96-checkbox">
                        <input type="checkbox" id="titled-applycss">
                        <span>Apply the CSS</span>
                    </label>
                    <button id="savebtn" class="w96-button">Save CSS</button>
                </div>
            `,
			initialHeight: 200,
			initialWidth: 400,
			taskbar: true,
            resizable: false,
            controlBoxStyle: "WS_CBX_CLOSE",
			icon: icons["16"]
		}, true);
		
        const wndBody = wnd.getBodyContainer();
        const allCSElements = wndBody.querySelectorAll(".titled-color-select");
        allCSElements.forEach(colorSelect => {
            const cinput = colorSelect.querySelector(".titled-color-select-input");
            const cpreview = colorSelect.querySelector(".titled-color-select-preview");
            cinput.addEventListener("input", () => {
                if(!(/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/gm.test(cinput.value))) return false;
                cpreview.style = "background-color: #" + cinput.value;
            });
        });

        function genCSS() {
            const active = {
                "col1": wndBody.querySelector('.titled-color-select-input[tcolor="1"][tstate="1"]').value,
                "col2": wndBody.querySelector('.titled-color-select-input[tcolor="2"][tstate="1"]').value,
                "rotation": wndBody.querySelector('.titled-rotation-input[tstate="1"]').value
            }
            const inactive = {
                "col1": wndBody.querySelector('.titled-color-select-input[tcolor="1"][tstate="2"]').value,
                "col2": wndBody.querySelector('.titled-color-select-input[tcolor="2"][tstate="2"]').value,
                "rotation": wndBody.querySelector('.titled-rotation-input[tstate="2"]').value
            }
            console.log([ active, inactive ])
            if(!(/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/gm.test(active.col1)) || !(/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/gm.test(active.col2)) || !(/^[0-9][0-9]?[0-9]?$/gm.test(active.rotation)) || parseInt(active.rotation) > 360 || !(/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/gm.test(inactive.col1)) || !(/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/gm.test(inactive.col2)) || !(/^[0-9][0-9]?[0-9]?$/gm.test(inactive.rotation)) || parseInt(inactive.rotation) > 360) return alert("Invalid input")
            const template = `
                .titlebar {
                    background: linear-gradient(${active.rotation}deg, #${active.col1}, #${active.col2});
                }
                .titlebar-title-disabled {
                    background: linear-gradient(${inactive.rotation}deg, #${inactive.col1}, #${inactive.col2});
                }
            `
            const saver = new w96.ui.SaveFileDialog("c:/system/boot", ["css"], path => {
                if(path === null || path.endsWith("/")) return false;
                try {
                    w96.FS.writestr(path, template);
                    if(wndBody.querySelector("#titled-applycss").checked) {
                        const sttag = document.createElement("style");
                        sttag.innerHTML = template;
                        document.body.appendChild(sttag)
                    }
                } catch(err) {
                    alert(err)
                }
            });
            saver.show()
        }
        wndBody.querySelector("#savebtn").addEventListener("click", genCSS)

		wnd.show();
	}
}

registerApp("titled", [], function(args) {
	return w96.WApplication.execAsync(new Titled(), args);
});

u96.shell.mkShortcut("c:/system/programs/Utility/Titled.link", icons["16"], "titled");