w96.sys.reg.deregisterApp("titled");
